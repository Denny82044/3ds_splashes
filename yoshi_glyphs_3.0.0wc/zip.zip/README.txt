Development has been discontinued for the "With Credits" version.
Who needs them anyway?

Total amount of time i've spent making this so far: 6hrs and 22mins